# How to Install? 
$ git clone https://github.com/bomi3/morocco.openai <br>
$ cd morocco.openai <br>
$ npm install <br>
$ node index.js <br>

Visit: <br>
 https://www.facebook.com/morocco.openai <br>
 https://www.instagram.com/morocco.openai

# How to get OpenAI API?
Visit: https://beta.openai.com/account/api-keys
